package pagetests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.MyHomePage;
import wdMethods.ProjectMethods;

public class CreateLead extends ProjectMethods{

	@BeforeClass
	public void setValues() {
		browserName = "chrome";
		dataSheetName = "CreateLead";
		testcaseName = "Create Lead";
		testDescription = "Create a new Lead with mandatory fields only";
		authorName = "Kaushik";
		category = "regression";
	}
	
	
	@Test(dataProvider="fetchData")
	public void createLead(String cName,String fName,String lName) {
		new MyHomePage(driver, test)
		.clickLeadTab()
		.clickCreateLead();
		
	}
}
