package pagetests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.MyHomePage;
import wdMethods.ProjectMethods;

public class EditLead extends ProjectMethods{

	@BeforeClass
	public void setValues() {
		browserName = "chrome";
		dataSheetName = "CreateLead";
		testcaseName = "Edit Lead";
		testDescription = "Edit an existing lead";
		authorName = "Babu";
		category = "smoke";
	}
	
	
	@Test(dataProvider="fetchData")
	public void editLead(String cName,String fName,String lName) {
		new MyHomePage(driver, test)
		.clickLeadTab()
		.clickFindLeads();
		
	}
}
